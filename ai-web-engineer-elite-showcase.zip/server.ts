import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

// Standard ESM equivalents for pathing
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // LAZY INITIALIZATION of the Gemini client
  let ai: GoogleGenAI | null = null;
  const getGeminiClient = (): GoogleGenAI => {
    if (!ai) {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        throw new Error("GEMINI_API_KEY is not defined in the environment secrets.");
      }
      ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });
    }
    return ai;
  };

  // API: Real-time AI Website Architecture & Feature Proposal generator
  app.post("/api/generate-proposal", async (req, res) => {
    const { businessName, businessType, aesthetic, features } = req.body;

    if (!businessName || !businessType) {
      return res.status(400).json({ error: "Please provide a Business Name and Business Type." });
    }

    try {
      const client = getGeminiClient();
      
      const prompt = `
        You are a world-class principal artificial intelligence software architect and lead product strategist designing custom, high-end web applications.
        Draft an premium website proposal and digital roadmap for this client:
        - Client Name: "${businessName}"
        - Business Type/Industry: "${businessType}"
        - Preferred Aesthetic/Vibe: "${aesthetic || 'Modern Editorial Black Canvas'}"
        - Key Required Features: ${Array.isArray(features) && features.length > 0 ? features.map(f => `"${f}"`).join(", ") : "Premium landing page, High conversion contact form, Interactive features"}

        Deliver your recommendation strictly in valid JSON format according to the requested structure.
        The response must be highly professional, persuasive, and highlight why custom AI-powered web development is superior to standard templates.
      `;

      const response = await client.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          systemInstruction: "You are the central AI Strategy engine for an elite digital software agency. Generate bespoke premium website design proposals strictly as structured JSON.",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              tagline: {
                type: Type.STRING,
                description: "A highly-persuasive, punchy, executive-level tagline for the client's new digital interface."
              },
              colorPalette: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    hex: { type: Type.STRING },
                    rationale: { type: Type.STRING }
                  }
                },
                description: "3 to 4 hex colors customized specifically to brand this system."
              },
              siteArchitecture: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    sectionName: { type: Type.STRING },
                    purpose: { type: Type.STRING },
                    microAnimation: { type: Type.STRING },
                    aiFactor: { type: Type.STRING, description: "How AI takes this section to 10x value" }
                  }
                },
                description: "Specific visual modules/sections recommended for their single-page app."
              },
              aiIntegrations: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    concept: { type: Type.STRING },
                    benefit: { type: Type.STRING }
                  }
                },
                description: "2 custom generative AI features or models we can bundle (e.g. live prompt calculators, intelligent responders, layout generators)."
              },
              timeline: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "3 high-level sequential sprint development phases (e.g. Iteration 1, 2, 3)."
              },
              closingPitch: {
                type: Type.STRING,
                description: "A short, sharp, premium executive pitch explaining why an AI-driven, bespoke design captures deeper client trust than a generic template."
              }
            },
            required: ["tagline", "colorPalette", "siteArchitecture", "aiIntegrations", "timeline", "closingPitch"]
          }
        }
      });

      if (!response.text) {
        throw new Error("No response content generated from Gemini.");
      }

      const proposal = JSON.parse(response.text.trim());
      return res.json({ proposal, isRealAI: true });

    } catch (error: any) {
      console.warn("AI Proposal generation fallback active due to:", error.message || error);
      
      // Highly premium, hyper-relevant fallback JSON that perfectly mirrors the schema
      // This ensures 100% reliability, zero crashes, even if API keys aren't set yet during preview testing
      const fallbackProposal = {
        tagline: `Unlocking Digital Advantage for ${businessName} with Intelligent Web Architecture.`,
        colorPalette: [
          { name: "Obsidian Canvas", hex: "#0B0F19", rationale: "Establishes a solid, elite foundation layout with rich depth." },
          { name: "Cyan Spark", hex: "#06B6D4", rationale: "Represents engineering intelligence and high-tech acceleration." },
          { name: "Muted Mercury", hex: "#94A3B8", rationale: "Clean corporate mercury-silver for absolute legible communication." }
        ],
        siteArchitecture: [
          {
            sectionName: "Engineering Identity Hero",
            purpose: "Establish high-end, visual dominance and instantly capture client target audiences.",
            microAnimation: "Slow cinematic 3D node canvas hover attractor pull.",
            aiFactor: "Bespoke dynamically personalized messaging depending on traffic origins."
          },
          {
            sectionName: "Intelligent Feature Matrix",
            purpose: "Interactive bento-grid showcasing features: " + (Array.isArray(features) && features.length > 0 ? features.join(", ") : "dynamic lead generation, premium visuals"),
            microAnimation: "Staggered spring cards on scroll entry.",
            aiFactor: "Each block is live-rendered based on user interest predictions."
          },
          {
            sectionName: "Custom Visual Showcase",
            purpose: "Highlight deep creative outputs and production capability.",
            microAnimation: "Smooth horizontal web layouts previews.",
            aiFactor: "Showcases AI-generated pixel layouts adapted to browser ratios."
          }
        ],
        aiIntegrations: [
          {
            title: "Generative Client Onboarding Agent",
            concept: "Captures user needs in conversational inputs and drafts interactive wireframe parameters instantly.",
            benefit: "Drives direct contact response by 240% compared to traditional static submit inputs."
          },
          {
            title: "Predictive UI Micro-adaptation",
            concept: "Tracks scrolling velocity and hover intent to naturally pre-fetch assets and glide animations smoothly.",
            benefit: "Bypasses noticeable latency for a pristine desktop and mobile scrolling experience."
          }
        ],
        timeline: [
          "Week 1: Algorithmic Wireframes & 3D WebGL Attractor Layouts",
          "Week 2: Secure Server API Integration & Conversational Onboarding Agent",
          "Week 3: Final Optimization, Multi-Platform Edge Cache Deploy & Live Verification"
        ],
        closingPitch: `A website is your 24/7 global storefront. Standard templates convey standard capability. Designing a custom AI-integrated platform for ${businessName} immediately establishes you as an industry front-runner, leveraging generative layout speed with surgical technical execution.`
      };

      return res.json({ proposal: fallbackProposal, isRealAI: false, note: "Loaded via strategic fallback model" });
    }
  });

  // API: AI Chat assistant
  app.post("/api/chat", async (req, res) => {
    const { messages } = req.body;

    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: "Missing or invalid chat messages." });
    }

    try {
      const client = getGeminiClient();
      
      // Map history to Google GenAI format
      const genAiMessages = messages.map((m: any) => ({
        role: m.role === "user" ? "user" : "model",
        parts: [{ text: m.content }]
      }));

      const systemInstruction = `You are 'Aether', an elite cybernetic virtual architect representing Alex Thorne (omrtamer56@gmail.com), an independent Principal AI Web Architect & Fullstack Engineer based in San Francisco, CA.
      Alex engineers custom, pristine, performance-focused, math-animated web environments using React 19, strict TypeScript, Express backends, Vite, and Tailwind CSS.
      He integrates intelligent Gemini model systems and never uses cookie-cutter templates.
      Your goal is to consult with the browser visitor, answer questions about his capabilities, tech stack, roadmap, and pricing.
      Speak with supreme composure, high aesthetic awareness, and sophisticated professionalism. Keep answers reasonably short, highly structured with markdown bullet points, italic highlights, or numbered lists. Always steer them towards copying his contacts or asking him for a custom proposal.`;

      const response = await client.models.generateContent({
        model: "gemini-3.5-flash",
        contents: genAiMessages,
        config: {
          systemInstruction,
          temperature: 0.7,
        }
      });

      return res.json({ response: response.text || "No response received.", isRealAI: true });

    } catch (error: any) {
      console.warn("AI Chatbox fallback triggered due to:", error.message || error);
      
      // Determine user's last message to provide a tailored smart answer
      const lastUserMsg = messages[messages.length - 1]?.content?.toLowerCase() || "";
      let reply = "";

      if (lastUserMsg.includes("proposal") || lastUserMsg.includes("hire") || lastUserMsg.includes("contact") || lastUserMsg.includes("email")) {
        reply = `I would be delighted to guide you into Alex's collaborative ecosystem! You can establish contact in two elite ways:
        
* **Direct Coordination:** Drop your project specs directly to Alex's personal coordinates at **omrtamer56@gmail.com**. He performs reviews personally within 12 hours.
* **Proposal Briefing:** Use our interactive project roadmap configurator above to draft tailored design briefs.

Would you like me to outline Alex's SLA support rates or standard contract terms next?`;
      } else if (lastUserMsg.includes("stack") || lastUserMsg.includes("tech") || lastUserMsg.includes("language") || lastUserMsg.includes("framework") || lastUserMsg.includes("programming")) {
        reply = `Alex designs layouts with a surgically-isolated, elite-performance core:
        
* **Frontend Architecture:** React 19, strict static type constraints (TypeScript), styled via tailwind utility vectors, and animated fluidly using fluid physical calculations.
* **Server Orchestration:** Custom Node/Express engines compiled via \`esbuild\` to guarantee zero package bloat and high-efficiency standard edge rendering.
* **AI Orchestration:** Deep integration of the next-generation \`@google/genai\` model endpoints for real-time generative layouts and search grounding.
* **No Telemetry Bloat:** Alex strictly excludes slow trackers or unrequested frameworks to maintain a flawless 60FPS viewport stream.

What business sectors are you targeting? I can advise on the ideal components for your visual stack.`;
      } else if (lastUserMsg.includes("roadmap") || lastUserMsg.includes("milestone") || lastUserMsg.includes("pipeline") || lastUserMsg.includes("deliver")) {
        reply = `An exceptional project requires custom milestones. Alex Thorne's standard corporate development pipeline spans a strict 16-day cycle:
        
1. **Phase 1: Discovery & State Blueprinting** (Days 1–3) – Mapping structural UML models, component hierarchies, and interactive states.
2. **Phase 2: High-Fidelity Development** (Days 4–12) – Engineering strict type metrics, custom animations, and secure backend routing.
3. **Phase 3: Render Optimization & Security Auditing** (Days 13–15) – Minimizing viewport latency, achieving 60FPS, and hardening sandbox scripts.
4. **Phase 4: SSL Live Staging & Deployment** (Day 16) – Secure variable staging on Cloud Run with complete source transfers.

Let me know if your team expects integration with custom systems like Jira or GitHub!`;
      } else if (lastUserMsg.includes("who are you") || lastUserMsg.includes("identity") || lastUserMsg.includes("name") || lastUserMsg.includes("aether")) {
        reply = `I am **Aether v1.4**, an elite cybernetic consulting chatbot designed specifically to represent the desk of Alex Thorne, Principal AI Web Architect. 

I'm here to analyze your digital spec, answer questions regarding Alex's custom typescript stack, unpack our launch milestones, and guide you on initiating a premium video briefing. 

How can I help engineer your digital presence today?`;
      } else {
        reply = `Greetings! As Alex Thorne's consulting assistant, I'm fully equipped to discuss custom web orchestration.

Alex designs high-status, math-animated React systems with server-side AI integrations. Rather than using rigid visual templates, we build clean, full-stack systems with custom backends in San Francisco, CA.

To help me coordinate your inquiry, we can cover:
* **The Custom Tech Stack** (React 19, TS, Vite, Node)
* **Project Roadmap & Phases** (Our rigorous 16-day pipeline)
* **Direct Consultations & Inquiries** (omrtamer56@gmail.com)

What aspects of your digital system can I outline for you?`;
      }

      return res.json({ response: reply, isRealAI: false });
    }
  });

  // Serve static assets or use Vite middleware
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*all", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[FULLSTACK SERVER] Booted at http://localhost:${PORT} in ${process.env.NODE_ENV || 'development'} mode.`);
  });
}

startServer();
