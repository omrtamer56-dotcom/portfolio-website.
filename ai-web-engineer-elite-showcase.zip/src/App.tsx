import React, { useState, useMemo } from "react";
import Background3D from "./components/Background3D";
import ProjectCard from "./components/ProjectCard";
import AIChatbox from "./components/AIChatbox";
import { PORTFOLIO_PROJECTS, CORE_TECH_STACKS, AGENCY_FEATURES } from "./data";
import { motion, AnimatePresence } from "motion/react";
import { 
  Cpu, 
  Terminal, 
  Sparkles, 
  Layers, 
  Activity, 
  Code, 
  UserCheck, 
  PhoneCall, 
  ArrowRight,
  Filter,
  CheckCircle2,
  Lock,
  Globe,
  CornerDownRight,
  Info,
  ChevronDown,
  Mail,
  MapPin,
  Calendar,
  Clock,
  ExternalLink,
  Briefcase,
  Compass
} from "lucide-react";

export default function App() {
  // Navigation & Page State
  const [activeTab, setActiveTab] = useState<"all" | "ai_app" | "fullstack" | "interactive">("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleProjectsCount, setVisibleProjectsCount] = useState(2);

  // Filter projects by category & term
  const filteredProjects = useMemo(() => {
    return PORTFOLIO_PROJECTS.filter((p) => {
      const matchCat = activeTab === "all" || p.category === activeTab;
      const matchSearch = p.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          p.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          p.tags.some(t => t.toLowerCase().includes(searchTerm.toLowerCase()));
      return matchCat && matchSearch;
    });
  }, [activeTab, searchTerm]);

  // Paginated/visible projects
  const visibleProjects = useMemo(() => {
    return filteredProjects.slice(0, visibleProjectsCount);
  }, [filteredProjects, visibleProjectsCount]);

  // Quick FAQ indices for professional profile depth
  const faqs = [
    {
      q: "What does 'Created with the Help of AI' mean for this portfolio?",
      a: "This portfolio website to its core, including its satisfying physical particle canvas simulation, responsive-designed layout math, and advanced data models, was designed and optimized in synergy with advanced artificial intelligence models. This is a practical showcase of how I leverage AI to build polished, production-ready, bulletproof digital platforms 10x faster."
    },
    {
      q: "What technical stack do you focus on when designing custom sites?",
      a: "My primary arsenal consists of React 19, TypeScript, Tailwind CSS v4 for supercharged styles, Framer Motion for cinematic interactive physics, and Node/Express for secure backend systems. I prefer building full-stack environments where sensitive keys are kept safe on the server."
    },
    {
      q: "How do we get started on an elite custom project?",
      a: "Simply send an inquiry to my direct email contact listed below. I will reach out within 24 hours to schedule a deep design-and-architecture consultation call where we blueprint your specific project goals and map out a tailored roadmap."
    }
  ];

  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  return (
    <div className="relative min-h-screen text-slate-100 overflow-x-hidden selection:bg-cyber-accent/30 selection:text-white">
      {/* 3D background math particle attractor */}
      <Background3D />

      {/* Modern Frosted glass background blurry lighting spheres */}
      <div className="absolute top-[8%] left-[-10%] w-[380px] h-[380px] bg-cyan-500/10 rounded-full blur-[110px] pointer-events-none animate-pulse-slow" />
      <div className="absolute top-[42%] right-[5%] w-[450px] h-[450px] bg-purple-500/10 rounded-full blur-[130px] pointer-events-none animate-pulse-slow" style={{ animationDelay: "2.2s" }} />
      <div className="absolute bottom-[8%] left-[15%] w-[320px] h-[320px] bg-emerald-500/10 rounded-full blur-[95px] pointer-events-none" />

      {/* Header Sticky Navigation (Frosted and Sleek) */}
      <header className="sticky top-0 z-50 w-full backdrop-blur-md bg-cyber-dark/40 border-b border-white/10 transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          
          {/* Logo mark */}
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyber-accent to-cyber-secondary flex items-center justify-center shadow-md shadow-cyan-500/10">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <div>
              <span className="font-display font-medium text-sm text-white tracking-tight">
                Alex Thorne <span className="text-cyber-accent">/</span> AI Web Architect
              </span>
            </div>
          </div>

          {/* Clean Rounded Capsule Navigation anchors */}
          <nav className="hidden lg:flex items-center bg-white/[0.03] border border-white/10 rounded-full p-1 shadow-inner">
            <a 
              href="#about" 
              className="text-gray-400 hover:text-white px-4 py-1.5 rounded-full text-[11px] font-mono font-medium tracking-wider transition-all duration-200 hover:bg-white/[0.05]"
            >
              01. ABOUT
            </a>
            <a 
              href="#portfolio" 
              className="text-gray-400 hover:text-white px-4 py-1.5 rounded-full text-[11px] font-mono font-medium tracking-wider transition-all duration-200 hover:bg-white/[0.05]"
            >
              02. PORTFOLIO
            </a>
            <a 
              href="#roadmap" 
              className="text-gray-400 hover:text-white px-4 py-1.5 rounded-full text-[11px] font-mono font-medium tracking-wider transition-all duration-200 hover:bg-white/[0.05]"
            >
              03. ROADMAP
            </a>
            <a 
              href="#skills" 
              className="text-gray-400 hover:text-white px-4 py-1.5 rounded-full text-[11px] font-mono font-medium tracking-wider transition-all duration-200 hover:bg-white/[0.05]"
            >
              04. SKILLS
            </a>
            <a 
              href="#contact" 
              className="text-gray-400 hover:text-white px-4 py-1.5 rounded-full text-[11px] font-mono font-medium tracking-wider transition-all duration-200 hover:bg-white/[0.05]"
            >
              05. CONTACT
            </a>
          </nav>

          {/* Quick Contact CTA Button */}
          <div>
            <a
              href="#contact"
              className="bg-cyber-accent/[0.08] hover:bg-cyber-accent text-cyber-accent hover:text-cyber-dark border border-cyber-accent/30 hover:border-transparent px-4 py-2 rounded-xl text-xs font-mono font-bold tracking-wide transition-all duration-305 shadow-sm"
            >
              EMAIL ME DIRECT
            </a>
          </div>
        </div>
      </header>

      {/* Main Page Layout Wrapper */}
      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section 1: Hero Identity - Expressing they sell websites & built with AI */}
        <section id="about" className="pt-16 pb-20 md:py-24 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center min-h-[calc(100vh-64px)] scroll-mt-14">
          
          {/* Left Column Text details */}
          <div className="lg:col-span-7 space-y-7">
            
            {/* AI Active Status label badge */}
            <div className="inline-flex items-center gap-2.5 bg-cyber-accent/10 border border-cyber-accent/30 py-1.5 px-3 rounded-full">
              <span className="w-2 h-2 bg-cyber-accent rounded-full animate-pulse" />
              <span className="text-[9px] font-mono text-cyan-300 font-bold uppercase tracking-widest">
                AI-COMMISSIONED WEB PRODUCTION
              </span>
            </div>

            {/* Core Value Proposition statement */}
            <h1 className="text-5xl sm:text-7xl lg:text-[5.5rem] xl:text-[6.2rem] font-extrabold tracking-tight font-display text-white leading-[1.02]">
              I Sell Premium <br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-400 to-emerald-400">
                Custom Web Systems.
              </span>
            </h1>

            {/* Explicit AI helper statement requested by user */}
            <div className="p-4 rounded-xl bg-white/5 border border-white/10 backdrop-blur-md space-y-2">
              <div className="flex items-center gap-2 text-cyber-accent">
                <Cpu className="w-4 h-4" />
                <span className="text-xs font-mono font-bold tracking-widest uppercase">Created with the Help of AI</span>
              </div>
              <p className="text-gray-300 text-sm leading-relaxed font-sans">
                Every component, mathematical 3D orbit backdrop, and state model on this website was engineered with the collaborative speed of advanced AI. This system serves as a pristine showcase of my technical expertise and AI-powered development services, delivering hand-tailored, high-fidelity digital products ready to capture client trust.
              </p>
            </div>

            <p className="text-gray-400 font-sans text-base max-w-2xl leading-relaxed">
              If your enterprise demands a high-conversion layout that looks spectacular, processes dynamic data sub-milliseconds, and converts scrolling visitors into active clients—I construct it from the ground up. No generic pre-packaged templates. Only raw, handcoded excellence.
            </p>

            {/* Three key service anchors */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
              <div className="p-4 rounded-xl bg-cyber-card/40 border border-gray-800">
                <Globe className="w-5 h-5 text-cyber-accent mb-2" />
                <h4 className="text-xs font-mono font-bold text-white uppercase tracking-wider">I Sell Websites</h4>
                <p className="text-[11px] text-gray-400 mt-1">High-end bespoke digital interfaces that establish instant status.</p>
              </div>
              <div className="p-4 rounded-xl bg-cyber-card/40 border border-gray-800">
                <Cpu className="w-5 h-5 text-cyber-secondary mb-2" />
                <h4 className="text-xs font-mono font-bold text-white uppercase tracking-wider">AI Augmented</h4>
                <p className="text-[11px] text-gray-400 mt-1">5-10x accelerated coding cycles and integrated generative capabilities.</p>
              </div>
              <div className="p-4 rounded-xl bg-cyber-card/40 border border-gray-800">
                <Layers className="w-5 h-5 text-cyber-emerald mb-2" />
                <h4 className="text-xs font-mono font-bold text-white uppercase tracking-wider">Premium Execution</h4>
                <p className="text-[11px] text-gray-400 mt-1">Sticking to strict, lightweight codebases with solid mobile UX speeds.</p>
              </div>
            </div>

            {/* CTA anchors */}
            <div className="flex flex-wrap items-center gap-4 pt-4">
              <a
                href="#contact"
                className="px-6 py-3 bg-cyber-accent hover:bg-cyan-400 text-cyber-dark font-display font-semibold rounded-xl transition-all shadow-md shadow-cyan-500/10 flex items-center gap-2 cursor-pointer"
              >
                <span>Hire to Build Your Site</span>
                <ArrowRight className="w-4 h-4" />
              </a>
              <a
                href="#portfolio"
                className="px-6 py-3 bg-white/5 hover:bg-white/10 border border-white/10 font-display font-medium rounded-xl transition-all cursor-pointer"
              >
                Inspect Portfolio Specs
              </a>
            </div>

          </div>

          {/* Right Column details card */}
          <div className="lg:col-span-5 relative">
            <div className="relative z-10 rounded-2xl bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-2xl border border-white/20 p-6 sm:p-8 space-y-6 shadow-2xl">
              
              <div className="flex justify-between items-center pb-4 border-b border-gray-800">
                <div className="flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-cyber-secondary animate-pulse" />
                  <span className="font-mono text-xs text-gray-300">architect_profile.md</span>
                </div>
                <span className="text-[9px] font-mono text-cyber-emerald font-bold tracking-widest bg-emerald-500/10 border border-emerald-500/20 px-2 rounded">
                  AVAILABLE NOW
                </span>
              </div>

              {/* Loop list details */}
              <div className="space-y-4">
                {AGENCY_FEATURES.map((feat, idx) => (
                  <div key={idx} className="space-y-1">
                    <h3 className="font-display font-bold text-sm text-white flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-cyber-accent" />
                      {feat.title}
                    </h3>
                    <p className="text-xs text-gray-400 leading-relaxed pl-3.5">
                      {feat.description}
                    </p>
                  </div>
                ))}
              </div>

              {/* Aesthetic note */}
              <div className="p-3 bg-cyber-accent/5 border border-cyber-accent/20 rounded-xl flex gap-2.5 text-xs text-cyan-300 leading-relaxed">
                <Info className="w-4 h-4 shrink-0 mt-0.5" />
                <span>
                  <strong>Performance Guarantee:</strong> Rest easy. While we utilize satisfying, high-fidelity 3D particle animations, the assets are strictly math-optimized to maintain immediate loading speeds to help retain your site ranking metrics.
                </span>
              </div>

            </div>

            <div className="absolute inset-0 bg-cyber-accent/5 rounded-2xl blur-xl pointer-events-none -m-1" />
          </div>

        </section>


        {/* Section 2: Portfolio Showcase */}
        <section id="portfolio" className="py-20 border-t border-gray-900 scroll-mt-14">
          
          <div className="text-center max-w-3xl mx-auto space-y-4 mb-12">
            <div className="flex justify-center items-center gap-2">
              <Activity className="w-5 h-5 text-cyber-accent" />
              <span className="text-xs font-mono font-bold text-cyber-accent uppercase tracking-widest">
                CASE STUDY REPOSITORY
              </span>
            </div>
            
            <h2 className="text-3xl sm:text-4xl font-extrabold font-display text-white tracking-tight">
              Premium Architecture Layouts
            </h2>
            
            <p className="text-sm text-gray-400 leading-relaxed">
              Explore actual high-end systems featuring modular react states, hardware graphics layers, and secure AI backend configurations. Tap "Inspect Blueprint" on any block to expand and review deep architectural specifications.
            </p>
          </div>

          {/* Filter Toolbar (Reusable state filter) */}
          <div className="bg-white/5 border border-white/10 backdrop-blur-md rounded-2xl p-4 mb-8 flex flex-col md:flex-row gap-4 items-center justify-between">
            
            <div className="flex bg-white/[0.03] border border-white/10 rounded-full p-1 gap-1 shadow-inner items-center overflow-x-auto max-w-full">
              {(["all", "ai_app", "fullstack", "interactive"] as const).map((catName) => (
                <button
                  key={catName}
                  onClick={() => {
                    setActiveTab(catName);
                    setVisibleProjectsCount(2); // reset results paging limit
                  }}
                  className={`text-xs px-4 py-1.5 rounded-full transition-all duration-300 cursor-pointer font-mono font-medium whitespace-nowrap ${
                    activeTab === catName
                      ? "bg-cyber-accent text-cyber-dark font-bold shadow-md shadow-cyan-500/10"
                      : "text-gray-400 hover:text-white hover:bg-white/[0.04]"
                  }`}
                >
                  {catName === "all" && "All Custom Specs"}
                  {catName === "ai_app" && "Intelligent Models"}
                  {catName === "fullstack" && "Hardware/Fullstack"}
                  {catName === "interactive" && "Interactive Closers"}
                </button>
              ))}
            </div>

            {/* In-page dynamic search */}
            <div className="relative w-full sm:w-72">
              <input
                type="text"
                placeholder="Search specs (e.g. React)..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-cyber-dark/85 border border-gray-800 focus:border-cyber-accent focus:outline-none rounded-xl px-3.5 py-1.5 text-xs text-gray-100 font-mono transition-colors placeholder:text-gray-600"
              />
              <span className="absolute right-3 top-2 text-[10px] text-gray-500 font-mono">
                {filteredProjects.length} found
              </span>
            </div>

          </div>

          {/* Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {visibleProjects.map((project) => (
              <ProjectCard key={project.id} project={project} />
            ))}

            {filteredProjects.length === 0 && (
              <div className="col-span-full py-16 text-center border border-dashed border-gray-800 rounded-2xl space-y-2">
                <Filter className="w-8 h-8 text-gray-600 mx-auto" />
                <p className="text-sm font-mono text-gray-400">No project blueprints match your active search terms.</p>
                <button
                  onClick={() => { setSearchTerm(""); setActiveTab("all"); }}
                  className="text-xs text-cyber-accent underline cursor-pointer"
                >
                  Reset parameters
                </button>
              </div>
            )}
          </div>

          {/* "Load More" controls if results exceed paging limits */}
          {filteredProjects.length > visibleProjects.length && (
            <div className="mt-12 text-center">
              <button
                onClick={() => setVisibleProjectsCount(p => p + 2)}
                className="px-5 py-2.5 bg-cyber-card hover:bg-gray-800 text-xs font-mono font-bold text-gray-300 hover:text-cyber-accent rounded-xl border border-gray-800 hover:border-cyber-accent/40 transition-all cursor-pointer"
              >
                [Load Rest of Blueprint Modules]
              </button>
            </div>
          )}

        </section>


        {/* Section 3: Project Roadmap & Enterprise Quality Pipeline */}
        <section id="roadmap" className="py-20 border-t border-gray-900 scroll-mt-20">
          
          <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
            <div className="flex justify-center items-center gap-2">
              <Compass className="w-5 h-5 text-cyber-accent" />
              <span className="text-xs font-mono font-bold text-cyber-accent uppercase tracking-widest">
                SYSTEM LAUNCH MILESTONES
              </span>
            </div>
            
            <h2 className="text-3xl sm:text-4xl font-extrabold font-display text-white tracking-tight">
              My Execution & Delivery Roadmap
            </h2>
            
            <p className="text-sm text-gray-400 leading-relaxed font-sans">
              Bespoke digital architecture is not built overnight. Learn how I guide complex client systems through rigorous software phases—ensuring uncompromised uptime, bulletproof data routing, and elite rendering performance.
            </p>
          </div>

          {/* Structured Bento Milestone Blocks */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 relative">
            
            {/* Visual connecting axis bar for desktop */}
            <div className="hidden md:block absolute top-1/2 left-4 right-4 h-0.5 bg-gradient-to-r from-cyber-accent/40 via-cyber-secondary/35 to-cyber-emerald/20 -translate-y-1/2 z-0 pointer-events-none" />

            {/* PHASE 1 */}
            <div className="relative z-10 bg-cyber-card/80 border border-gray-800 rounded-2xl p-6 backdrop-blur-md flex flex-col space-y-4 hover:border-cyber-accent/30 transition-all">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-mono text-cyber-accent font-bold uppercase tracking-wider bg-cyber-accent/10 border border-cyber-accent/20 px-2 py-0.5 rounded">
                  Phase 1 / Blueprint
                </span>
                <span className="text-xs font-mono text-gray-500 font-semibold">T: Days 1-3</span>
              </div>
              <div className="space-y-1.5">
                <h3 className="font-display font-semibold text-base text-white">Discovery & Architecture</h3>
                <p className="text-xs text-gray-400 leading-relaxed font-sans">
                  We formulate precise requirements, database schemas, component hierarchies, and interactive models. Every interface state is blueprinted prior to writing a single line of production code.
                </p>
              </div>
              <ul className="space-y-1 text-[11px] text-gray-300 font-mono pt-2 border-t border-gray-800/60">
                <li className="flex items-center gap-1.5">
                  <span className="w-1 h-1 bg-cyber-accent rounded-full shrink-0" />
                  <span>State Model Design</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="w-1 h-1 bg-cyber-accent rounded-full shrink-0" />
                  <span>UML Route Map Layout</span>
                </li>
              </ul>
            </div>

            {/* PHASE 2 */}
            <div className="relative z-10 bg-cyber-card/80 border border-gray-800 rounded-2xl p-6 backdrop-blur-md flex flex-col space-y-4 hover:border-cyber-accent/30 transition-all">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-mono text-cyber-secondary font-bold uppercase tracking-wider bg-cyber-secondary/10 border border-cyber-secondary/20 px-2 py-0.5 rounded">
                  Phase 2 / Dev
                </span>
                <span className="text-xs font-mono text-gray-500 font-semibold">T: Days 4-12</span>
              </div>
              <div className="space-y-1.5">
                <h3 className="font-display font-semibold text-base text-white">Advanced Interactive Build</h3>
                <p className="text-xs text-gray-400 leading-relaxed font-sans">
                  Writing structural code using React 19, strict TypeScript parameters, and styling utilities. Leverages high-end coordinate frameworks to deliver satisfying dynamic visuals.
                </p>
              </div>
              <ul className="space-y-1 text-[11px] text-gray-300 font-mono pt-2 border-t border-gray-800/60">
                <li className="flex items-center gap-1.5">
                  <span className="w-1 h-1 bg-cyber-secondary rounded-full shrink-0" />
                  <span>Strict Type Checks</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="w-1 h-1 bg-cyber-secondary rounded-full shrink-0" />
                  <span>API Proxy Endpoints</span>
                </li>
              </ul>
            </div>

            {/* PHASE 3 */}
            <div className="relative z-10 bg-cyber-card/80 border border-gray-800 rounded-2xl p-6 backdrop-blur-md flex flex-col space-y-4 hover:border-cyber-accent/30 transition-all">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-mono text-cyber-accent font-bold uppercase tracking-wider bg-cyber-accent/10 border border-cyber-accent/20 px-2 py-0.5 rounded">
                  Phase 3 / Speed
                </span>
                <span className="text-xs font-mono text-gray-500 font-semibold">T: Days 13-15</span>
              </div>
              <div className="space-y-1.5">
                <h3 className="font-display font-semibold text-base text-white">Surgical Optimization</h3>
                <p className="text-xs text-gray-400 leading-relaxed font-sans">
                  Rigorous audits. We ensure 60FPS fluid viewport motion, minimize third-party asset bloat, optimize rendering structures, and setup safe sandboxed frames for zero exploit opportunities.
                </p>
              </div>
              <ul className="space-y-1 text-[11px] text-gray-300 font-mono pt-2 border-t border-gray-800/60">
                <li className="flex items-center gap-1.5">
                  <span className="w-1 h-1 bg-cyber-accent rounded-full shrink-0" />
                  <span>Frame Render Virtualization</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="w-1 h-1 bg-cyber-accent rounded-full shrink-0" />
                  <span>Security Sandbox Setup</span>
                </li>
              </ul>
            </div>

            {/* PHASE 4 */}
            <div className="relative z-10 bg-cyber-card/80 border border-gray-800 rounded-2xl p-6 backdrop-blur-md flex flex-col space-y-4 hover:border-cyber-accent/30 transition-all">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-mono text-cyber-emerald font-bold uppercase tracking-wider bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded">
                  Phase 4 / Launch
                </span>
                <span className="text-xs font-mono text-gray-500 font-semibold">T: Day 16</span>
              </div>
              <div className="space-y-1.5">
                <h3 className="font-display font-semibold text-base text-white">SSL Deploy & Transfer</h3>
                <p className="text-xs text-gray-400 leading-relaxed font-sans">
                  The client application is launched directly to secure autoscaling cloud endpoints with customized access variables. All project materials are shared cleanly.
                </p>
              </div>
              <ul className="space-y-1 text-[11px] text-gray-300 font-mono pt-2 border-t border-gray-800/60">
                <li className="flex items-center gap-1.5">
                  <span className="w-1 h-1 bg-cyber-emerald rounded-full shrink-0" />
                  <span>Cloud Run Ingress Staging</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="w-1 h-1 bg-cyber-emerald rounded-full shrink-0" />
                  <span>Secret Variables Swap</span>
                </li>
              </ul>
            </div>

          </div>

          {/* Quality badge declaration to keep it highly organized */}
          <div className="mt-8 p-4 rounded-xl bg-white/[0.02] border border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-xs text-gray-300 font-sans">
              <Info className="w-4 h-4 text-cyber-accent" />
              <span>Are you targeting a custom corporate deployment? All of these roadmap phases can be synced to your internally preferred Jira or GitHub environments.</span>
            </div>
            <div className="font-mono text-[10px] text-gray-500 font-semibold bg-white/5 px-3 py-1 rounded-md">
              [PIPELINE CALIBRATED]
            </div>
          </div>

        </section>

        {/* Section 4: Professional Technical Skills */}
        <section id="skills" className="py-20 border-t border-gray-900 scroll-mt-20">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            
            {/* Left Block details */}
            <div className="lg:col-span-5 space-y-6">
              
              <div className="flex items-center gap-2">
                <Code className="w-5 h-5 text-cyber-secondary" />
                <span className="text-xs font-mono font-bold text-cyber-secondary uppercase tracking-widest block">
                  TECHNICAL CAPABILITIES INDEX
                </span>
              </div>

              <h2 className="text-3xl font-extrabold font-display text-white">
                Surgical Command of Web Infrastructure
              </h2>

              <p className="text-sm text-gray-400 leading-relaxed font-sans">
                My production workflows are calibrated to balance premium visual output with secure, lightweight system code. By integrating strict TypeScript rules, performant node configurations, and seamless canvas vector structures, I guarantee zero latency bottlenecks on any browser size.
              </p>

              {/* Developer statement block */}
              <div className="bg-cyber-secondary/5 border border-cyber-secondary/20 p-4 rounded-xl space-y-2.5">
                <span className="text-xs font-mono font-bold text-cyber-secondary uppercase tracking-widest block">
                  AI-Assisted Efficiency Gains:
                </span>
                <ul className="space-y-1.5 text-xs text-gray-300 font-sans">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-cyber-accent shrink-0" />
                    <span>Real-time code refactoring validation patterns</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-cyber-accent shrink-0" />
                    <span>Instant viewport responsiveness calculation maps</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-cyber-accent shrink-0" />
                    <span>Automated database schema updates</span>
                  </li>
                </ul>
              </div>

            </div>

            {/* Right block: Skill gauges */}
            <div className="lg:col-span-7 bg-cyber-card/75 backdrop-blur-lg border border-gray-800 rounded-2xl p-6 sm:p-8 space-y-6">
              
              <div className="flex items-center justify-between pb-3 border-b border-gray-800">
                <span className="text-xs font-mono text-gray-400 uppercase tracking-wider block">
                  Calibrated Technology Stack
                </span>
                <span className="text-[10px] font-mono text-cyber-accent">
                  Updated: June 2026
                </span>
              </div>

              {/* Skill gauges */}
              <div className="space-y-5">
                {CORE_TECH_STACKS.map((stack) => (
                  <div key={stack.name} className="space-y-1.5">
                    
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-bold text-white font-display">
                        {stack.name}
                      </span>
                      <span className="font-mono text-cyber-accent font-semibold">
                        {stack.level}% Proficiency Score
                      </span>
                    </div>

                    {/* Progress Fill bar */}
                    <div className="w-full bg-cyber-dark border border-gray-800 h-2.5 rounded-full overflow-hidden">
                      <div
                        className="bg-gradient-to-r from-cyber-accent to-cyber-secondary h-full rounded-full transition-all duration-1000"
                        style={{ width: `${stack.level}%` }}
                      />
                    </div>

                    <span className="text-[11px] text-gray-400 block leading-relaxed leading-slate">
                      {stack.role}
                    </span>

                  </div>
                ))}
              </div>

            </div>

          </div>
        </section>


        {/* Section FAQ: Added to build substantial premium context */}
        <section className="py-20 border-t border-gray-900">
          <div className="text-center max-w-3xl mx-auto space-y-3 mb-10">
            <span className="text-xs font-mono text-gray-500 uppercase tracking-widest block">
              HAVE QUESTIONS ABOUT PREMIUM OUTSOURCING?
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold font-display text-white">
              Absolute Engineering Clarity
            </h2>
          </div>

          <div className="max-w-3xl mx-auto space-y-3.5">
            {faqs.map((faq, i) => {
              const isOpen = activeFaq === i;
              return (
                <div
                  key={i}
                  className="bg-cyber-card/60 backdrop-blur-md border border-gray-800 hover:border-gray-700 rounded-xl overflow-hidden transition-colors"
                >
                  <button
                    onClick={() => setActiveFaq(isOpen ? null : i)}
                    className="w-full px-5 py-4 text-left font-display text-sm font-semibold text-white flex justify-between items-center gap-4 cursor-pointer"
                  >
                    <span>{faq.q}</span>
                    <span className={`text-cyber-accent transition-transform duration-300 ${isOpen ? "rotate-180" : ""}`}>
                      <ChevronDown className="w-4 h-4" />
                    </span>
                  </button>
                  <AnimatePresence>
                    {isOpen && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden"
                      >
                        <p className="px-5 pb-5 text-xs text-gray-400 leading-relaxed font-sans border-t border-gray-800/40 pt-2.5">
                          {faq.a}
                        </p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>
        </section>


        {/* Section 4: Highly Polished Contact Module */}
        <section id="contact" className="py-20 border-t border-gray-900 scroll-mt-20">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
            
            {/* Left Block text details */}
            <div className="lg:col-span-5 space-y-6 flex flex-col justify-between">
              
              <div className="space-y-6">
                <div className="flex items-center gap-2">
                  <PhoneCall className="w-5 h-5 text-cyber-accent" />
                  <span className="text-xs font-mono font-bold text-cyber-accent uppercase tracking-widest block">
                    KICKOFF DESIGN SESSIONS
                  </span>
                </div>

                <h2 className="text-3xl font-extrabold font-display text-white tracking-tight">
                  Blueprint Your Custom Interface
                </h2>

                <p className="text-sm text-gray-400 leading-relaxed font-sans">
                  Ready to elevate your digital status with a premium, optimized web ecosystem? Skip the generic forms and reach out directly. I review all serious architecture inquiries personally within 12 hours.
                </p>

                <div className="space-y-4 pt-2">
                  <div className="flex gap-3.5 items-start">
                    <div className="w-9 h-9 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-cyber-accent font-mono text-xs font-bold shrink-0">
                      S1
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white uppercase font-mono">1. Direct Communication</h4>
                      <p className="text-[11px] text-gray-400 font-sans">Reach out via standard mail with your general project scope parameters.</p>
                    </div>
                  </div>

                  <div className="flex gap-3.5 items-start">
                    <div className="w-9 h-9 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-cyber-secondary font-mono text-xs font-bold shrink-0">
                      S2
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white uppercase font-mono">2. Video Blueprint Workshop</h4>
                      <p className="text-[11px] text-gray-400 font-sans">We lock in a 1-on-1 session mapping typographic directions, WebGL components, and API constraints.</p>
                    </div>
                  </div>

                  <div className="flex gap-3.5 items-start">
                    <div className="w-9 h-9 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-cyber-emerald font-mono text-xs font-bold shrink-0">
                      S3
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white uppercase font-mono">3. Complete High-Fidelity Launch</h4>
                      <p className="text-[11px] text-gray-400 font-sans">Accelerated compilation using modern AI orchestration tools, launching directly to live Cloud, code fully integrated.</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Secure lock note to reinforce design values */}
              <div className="p-4 bg-white/[0.02] border border-white/5 rounded-xl flex gap-3 text-xs text-gray-400 leading-relaxed">
                <Lock className="w-4 h-4 text-cyber-accent shrink-0 mt-0.5" />
                <span>
                  <strong>Strict Security:</strong> Your contact coordinates and project designs have total isolation. No telemetry sharing, no third-party selling, and zero cookies tracker script injections. Period.
                </span>
              </div>

            </div>

            {/* Right block: Elite Direct Credentials / No Mock-up Contact details */}
            <div className="lg:col-span-7 bg-cyber-card/65 backdrop-blur-xl border border-white/10 rounded-2xl p-6 sm:p-8 flex flex-col justify-between space-y-6">
              
              <div className="space-y-4">
                <div className="pb-3 border-b border-gray-850">
                  <h3 className="font-display font-bold text-sm text-white">
                    Direct Coordination & Credentials
                  </h3>
                  <span className="text-[10px] font-mono text-gray-500 block mt-0.5">
                    No mock briefing grids. Coordinate directly with the architect desk for enterprise assignments
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl bg-cyber-dark/80 border border-gray-800/80 space-y-1">
                    <span className="text-[9px] font-mono text-gray-500 uppercase tracking-wider block">CONTACT COORDINATE</span>
                    <span className="text-xs font-mono font-bold text-white block">omrtamer56@gmail.com</span>
                  </div>
                  <div className="p-4 rounded-xl bg-cyber-dark/80 border border-gray-800/80 space-y-1">
                    <span className="text-[9px] font-mono text-gray-500 uppercase tracking-wider block">PRIMARY BASE TERMINAL</span>
                    <span className="text-xs font-mono font-bold text-white block">San Francisco, CA</span>
                  </div>
                  <div className="p-4 rounded-xl bg-cyber-dark/80 border border-gray-800/80 space-y-1">
                    <span className="text-[9px] font-mono text-gray-500 uppercase tracking-wider block">CONSULTING SLA RATE</span>
                    <span className="text-xs font-mono font-bold text-cyber-emerald block">&lt; 12-Hour Ticket Response</span>
                  </div>
                  <div className="p-4 rounded-xl bg-cyber-dark/80 border border-gray-800/80 space-y-1">
                    <span className="text-[9px] font-mono text-gray-500 uppercase tracking-wider block">ACTIVE ENGAGEMENT</span>
                    <span className="text-xs font-mono font-bold text-cyber-accent block">Q2-Q3 2026 Commission Booking</span>
                  </div>
                </div>

                <p className="text-xs text-gray-400 font-sans leading-relaxed">
                  As an independent AI Web Architect and full-stack engineer, I specialize in creating high-status, math-animated web environments that deliver pristine typography and fast page-loading speeds. Shoot over an email with your project outline specifications or technical goals, and let's structure your vision securely.
                </p>
              </div>

              {/* Direct email interactive controls */}
              <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-gray-800">
                <a
                  href="mailto:omrtamer56@gmail.com"
                  className="flex-1 bg-gradient-to-r from-cyber-accent to-cyber-secondary hover:opacity-95 text-white font-display font-semibold px-6 py-3 rounded-xl transition-all shadow-md shadow-cyan-500/10 cursor-pointer flex items-center justify-center gap-2"
                >
                  <Mail className="w-4 h-4" />
                  <span>Send Direct Email Inquiry</span>
                </a>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText("omrtamer56@gmail.com");
                    alert("Email address copied to your device clipboard!");
                  }}
                  className="px-5 py-3 bg-white/5 hover:bg-white/10 text-xs font-mono font-bold text-gray-300 rounded-xl border border-white/10 hover:border-white/20 transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <Briefcase className="w-4 h-4 shrink-0" />
                  <span>Copy Coordination Coordinates</span>
                </button>
              </div>

            </div>

          </div>
        </section>

      </main>

      {/* Footer System */}
      <footer className="relative z-10 bg-cyber-deep border-t border-white/10 mt-20 pt-10 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-10 pb-10 border-b border-gray-800">
            
            {/* Logo Statement */}
            <div className="md:col-span-5 space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-md bg-gradient-to-br from-cyber-accent to-cyber-secondary flex items-center justify-center">
                  <Sparkles className="w-3.5 h-3.5 text-white" />
                </div>
                <span className="font-display font-medium text-xs text-white tracking-tight">
                  Alex Thorne <span className="text-cyber-accent">/</span> AI Web Architect
                </span>
              </div>
              <p className="text-xs text-gray-400 leading-relaxed font-sans max-w-sm">
                I construct high-end custom handcoded websites engineered with the accelerated speeds of advanced generative intelligence, ensuring absolute brand credibility.
              </p>
            </div>

            {/* Quick anchors */}
            <div className="md:col-span-3 space-y-3">
              <h4 className="text-[10px] font-mono text-gray-400 uppercase tracking-widest font-bold">
                Anchor Directories
              </h4>
              <ul className="space-y-2 text-xs font-sans font-medium">
                <li>
                  <a href="#about" className="text-gray-300 hover:text-cyber-accent transition-colors">
                    Services Identity Outline
                  </a>
                </li>
                <li>
                  <a href="#portfolio" className="text-gray-300 hover:text-cyber-accent transition-colors">
                    Case Studies Directory
                  </a>
                </li>
                <li>
                  <a href="#roadmap" className="text-gray-300 hover:text-cyber-accent transition-colors">
                    Execution & Launch Roadmap
                  </a>
                </li>
                <li>
                  <a href="#skills" className="text-gray-300 hover:text-cyber-accent transition-colors">
                    Core Technical Index
                  </a>
                </li>
                <li>
                  <a href="#contact" className="text-gray-300 hover:text-cyber-accent transition-colors">
                    Direct Coordination Hub
                  </a>
                </li>
              </ul>
            </div>

            {/* Legal / Social Links */}
            <div className="md:col-span-4 space-y-3">
              <h4 className="text-[10px] font-mono text-gray-400 uppercase tracking-widest font-bold">
                Venture Status Metrics
              </h4>
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between max-w-xs">
                  <span className="text-gray-400">Current Status:</span>
                  <span className="text-cyber-emerald font-semibold">Ready for Consultancy</span>
                </div>
                <div className="flex justify-between max-w-xs">
                  <span className="text-gray-400">Primary Core Base:</span>
                  <span className="text-gray-300">San Francisco, CA</span>
                </div>
                <div className="flex justify-between max-w-xs">
                  <span className="text-gray-400 font-mono">Build System:</span>
                  <span className="text-cyan-300 font-mono text-[11px]">AI Studio v2026.06</span>
                </div>
              </div>
            </div>

          </div>

          {/* Bottom Copyright and compliance declaration */}
          <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] font-mono text-gray-450 text-gray-500">
            <p>
              &copy; {new Date().getFullYear()} Alex Thorne. All rights, custom layouts, and source coordinates reserved.
            </p>
            <p className="flex items-center gap-1">
              <Lock className="w-3 h-3 text-cyber-accent" />
              <span>Compliant with strict sandboxed iframe secure protocols.</span>
            </p>
          </div>

        </div>
      </footer>
      <AIChatbox />
    </div>
  );
}
