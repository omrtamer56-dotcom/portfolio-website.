import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  MessageSquare, 
  X, 
  Send, 
  Sparkles, 
  Bot, 
  User, 
  CornerDownRight, 
  ExternalLink,
  ChevronDown
} from "lucide-react";

interface ChatMessage {
  role: "user" | "model";
  content: string;
}

export default function AIChatbox() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: "model",
      content: "Greetings. I am **Aether v1.4**, an elite cybernetic virtual consultant representing the desk of Alex Thorne, Principal AI Web Architect.\n\nI can analyze your system spec, outline our **16-day launch roadmap**, or unpack Alex's modern developer tech stack. What digital vision can I help structure for you today?"
    }
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll on new messages
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, isTyping]);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim() || isTyping) return;

    const userMsg: ChatMessage = { role: "user", content: textToSend };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsTyping(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: [...messages, userMsg] }),
      });

      if (!response.ok) {
        throw new Error("Chat api failed");
      }

      const data = await response.json();
      setMessages((prev) => [...prev, { role: "model", content: data.response }]);
    } catch (err) {
      console.error("Failed to fetch chat:", err);
      // Premium error state response
      setMessages((prev) => [
        ...prev,
        {
          role: "model",
          content: "System Latency Detected. Alex's direct terminal is highly active. You can bypass this node and establish direct communication at **omrtamer56@gmail.com** for immediate answers."
        }
      ]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleSuggestionClick = (suggestionText: string) => {
    handleSendMessage(suggestionText);
  };

  const currentYear = new Date().getFullYear();

  return (
    <>
      {/* Floating Sparkle Trigger Button */}
      <div className="fixed bottom-6 right-6 z-50">
        <button
          onClick={() => setIsOpen(!isOpen)}
          id="ai-chatbox-trigger"
          className={`relative w-14 h-14 rounded-full bg-gradient-to-r from-cyber-accent via-indigo-500 to-cyber-secondary p-[1px] shadow-lg shadow-cyan-500/20 active:scale-95 transition-all duration-300 focus:outline-none flex items-center justify-center cursor-pointer ${
            isOpen ? "rotate-90 hover:shadow-cyan-500/30" : "hover:scale-105 hover:shadow-cyan-500/40"
          }`}
        >
          {/* Internal Button Fill */}
          <div className="w-full h-full rounded-full bg-cyber-dark/95 flex items-center justify-center text-white relative group overflow-hidden">
            <div className="absolute inset-0 bg-cyan-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            {isOpen ? (
              <X className="w-5 h-5 text-cyber-accent" />
            ) : (
              <div className="relative">
                <MessageSquare className="w-5 h-5 text-cyan-400 group-hover:text-white transition-colors duration-200" />
                <span className="absolute -top-1.5 -right-1.5 flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyber-accent"></span>
                </span>
              </div>
            )}
          </div>
        </button>
      </div>

      {/* Slide-out / Pop-up Premium Frosted Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 40, scale: 0.92 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.94 }}
            transition={{ type: "spring", damping: 25, stiffness: 220 }}
            id="ai-chatbox-panel"
            className="fixed bottom-24 right-6 w-[360px] sm:w-[400px] h-[520px] bg-cyber-card/75 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-2xl shadow-black/80 z-50 flex flex-col overflow-hidden"
          >
            {/* Elegant Header */}
            <div className="bg-cyber-dark/40 border-b border-white/5 p-4 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-cyber-accent/10 border border-cyber-accent/20 flex items-center justify-center relative">
                  <Bot className="w-4 h-4 text-cyber-accent" />
                  <span className="absolute bottom-0 right-0 w-2 h-2 rounded-full bg-cyber-emerald border border-cyber-dark" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h3 className="text-xs font-mono font-bold text-white tracking-wider">AETHER v1.4</h3>
                    <span className="text-[9px] font-mono text-cyan-400 bg-cyan-500/10 px-1 py-0.5 rounded leading-none">AI Agent</span>
                  </div>
                  <span className="text-[10px] text-gray-400 tracking-wide font-sans">Alex Thorne Consulting Desk</span>
                </div>
              </div>

              {/* Header actions */}
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-1 rounded bg-white/5 hover:bg-white/10 border border-white/5 hover:border-white/10 text-gray-400 hover:text-white transition-all cursor-pointer"
                >
                  <ChevronDown className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Message Flow Feed */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
              {messages.map((msg, i) => (
                <div
                  key={i}
                  className={`flex gap-2.5 ${msg.role === "user" ? "flex-row-reverse" : "flex-row"}`}
                >
                  {/* Icon Node */}
                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 border ${
                    msg.role === "user" 
                      ? "bg-cyber-secondary/15 border-cyber-secondary/30 text-cyber-secondary" 
                      : "bg-cyber-accent/10 border-cyber-accent/20 text-cyber-accent"
                  }`}>
                    {msg.role === "user" ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
                  </div>

                  {/* Body Speech Bubble */}
                  <div className={`max-w-[78%] rounded-xl p-3 text-xs leading-relaxed ${
                    msg.role === "user"
                      ? "bg-cyber-secondary/[0.08] text-white border border-cyber-secondary/20 rounded-tr-none"
                      : "bg-white/[0.02] text-gray-100 border border-white/5 rounded-tl-none font-sans"
                  }`}>
                    {msg.role === "model" ? (
                      <MessageContent text={msg.content} />
                    ) : (
                      <p className="font-sans text-gray-100">{msg.content}</p>
                    )}
                  </div>
                </div>
              ))}

              {/* Bot thinking placeholder */}
              {isTyping && (
                <div className="flex gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-cyber-accent/10 border border-cyber-accent/20 flex items-center justify-center shrink-0 text-cyber-accent">
                    <Bot className="w-3.5 h-3.5 animate-pulse" />
                  </div>
                  <div className="bg-white/[0.02] text-gray-400 border border-white/5 rounded-xl rounded-tl-none p-3 flex gap-1 items-center w-14">
                    <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-bounce [animation-delay:-0.3s]" />
                    <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-bounce [animation-delay:-0.15s]" />
                    <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-bounce" />
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Quick Suggestions Shelf */}
            {messages.length < 5 && (
              <div className="px-4 py-2 border-t border-white/5 bg-cyber-dark/20 flex flex-wrap gap-1.5">
                {[
                  { label: "🛠️ Alex's Tech Stack", text: "What programming languages and tech stack are you using?" },
                  { label: "📅 16-Day Project Roadmap", text: "Unpack the 16-day project milestone roadmap" },
                  { label: "📨 Direct Contacts Coordinate", text: "How can I contact Alex Thorne directly?" },
                  { label: "⚡ AI Software Velocity", text: "How does AI speed up development?" }
                ].map((chip, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSuggestionClick(chip.text)}
                    className="text-[10px] font-mono text-gray-400 hover:text-cyber-accent bg-white/[0.02] hover:bg-white/[0.06] border border-white/5 hover:border-cyber-accent/30 px-2.5 py-1 rounded-full transition-all cursor-pointer whitespace-nowrap"
                  >
                    {chip.label}
                  </button>
                ))}
              </div>
            )}

            {/* Input Box Footer Form */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage(input);
              }}
              className="p-3 border-t border-white/5 bg-cyber-dark/40 flex items-center gap-2"
            >
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask coordinates regarding architecture..."
                className="flex-1 bg-cyber-dark/90 border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/30 transition-all font-sans"
              />
              <button
                type="submit"
                disabled={!input.trim() || isTyping}
                className="w-8 h-8 rounded-lg bg-cyber-accent hover:opacity-90 disabled:opacity-45 text-cyber-dark flex items-center justify-center transition-opacity cursor-pointer active:scale-95 duration-100"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>

            {/* Security Isolation Footer Note */}
            <div className="bg-cyber-dark/60 text-center py-1.5 border-t border-white/5">
              <span className="text-[8px] font-mono text-gray-500 tracking-wider">
                OMRTAMER CONSUL SERVICE // ISOLATED CONTEXT STREAM &copy; {currentYear}
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

// Markdown formatting helper subcomponents
const MessageContent: React.FC<{ text: string }> = ({ text }) => {
  const lines = text.split("\n");
  return (
    <div className="space-y-2 text-xs leading-relaxed text-gray-200">
      {lines.map((line, idx) => {
        const trimmed = line.trim();
        if (!trimmed) return <div key={idx} className="h-1" />;

        // Bullet point check
        if (trimmed.startsWith("*") || trimmed.startsWith("-")) {
          const content = trimmed.substring(1).trim();
          return (
            <div key={idx} className="flex gap-1.5 items-start pl-1">
              <span className="text-cyan-400 mt-1 shrink-0 text-[8px]">◆</span>
              <span>{renderBold(content)}</span>
            </div>
          );
        }

        // Ordered list check
        const numberMatch = trimmed.match(/^(\d+)\.\s+(.*)/);
        if (numberMatch) {
          const num = numberMatch[1];
          const content = numberMatch[2];
          return (
            <div key={idx} className="flex gap-1.5 items-start pl-1">
              <span className="text-cyan-400 font-mono font-bold">{num}.</span>
              <span>{renderBold(content)}</span>
            </div>
          );
        }

        return <p key={idx}>{renderBold(line)}</p>;
      })}
    </div>
  );
};

// Simple bold / code formatting engine
function renderBold(str: string) {
  const parts: React.ReactNode[] = [];
  const boldRegex = /\*\*(.*?)\*\*/g;
  let lastIndex = 0;
  let match;

  while ((match = boldRegex.exec(str)) !== null) {
    const textBefore = str.substring(lastIndex, match.index);
    if (textBefore) {
      parts.push(...renderCode(textBefore));
    }
    parts.push(
      <strong key={match.index} className="text-cyan-300 font-bold font-sans">
        {match[1]}
      </strong>
    );
    lastIndex = boldRegex.lastIndex;
  }
  
  const textRemaining = str.substring(lastIndex);
  if (textRemaining) {
    parts.push(...renderCode(textRemaining));
  }
  
  return parts.length > 0 ? <>{parts}</> : <span>{str}</span>;
}

// Sub-render backticks (e.g. `npm run dev`)
function renderCode(text: string): React.ReactNode[] {
  const parts: React.ReactNode[] = [];
  const codeRegex = /`(.*?)`/g;
  let lastIndex = 0;
  let match;

  while ((match = codeRegex.exec(text)) !== null) {
    const textBefore = text.substring(lastIndex, match.index);
    if (textBefore) parts.push(textBefore);
    parts.push(
      <code key={match.index} className="bg-white/5 border border-white/10 px-1 py-0.5 rounded font-mono text-[10px] text-emerald-300">
        {match[1]}
      </code>
    );
    lastIndex = codeRegex.lastIndex;
  }
  
  const textRemaining = text.substring(lastIndex);
  if (textRemaining) parts.push(textRemaining);
  
  return parts;
}
