import { useEffect, useRef } from "react";

interface Particle {
  x: number;
  y: number;
  z: number;
  ox: number; // Original x (for spring back)
  oy: number;
  oz: number;
  color: string;
  size: number;
  vx: number;
  vy: number;
  vz: number;
  type: "sphere" | "helix_a" | "helix_b";
}

export default function Background3D() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const mouseRef = useRef({ x: 0, y: 0, rx: 0, ry: 0, active: false });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const particles: Particle[] = [];
    const particleCount = width < 768 ? 80 : 160;

    // Projection variables
    const focalLength = 320; // Lower number = more dramatic perspective
    let angleX = 0.001; // Base continuous rotation
    let angleY = 0.0025;

    // Generate coordinates
    // Core AI smart sphere:
    const sphereRadius = width < 768 ? 90 : 130;
    const sphereCount = Math.floor(particleCount * 0.4);
    for (let i = 0; i < sphereCount; i++) {
      const theta = Math.acos(Math.random() * 2 - 1);
      const phi = Math.random() * Math.PI * 2;

      const x = sphereRadius * Math.sin(theta) * Math.cos(phi);
      const y = sphereRadius * Math.sin(theta) * Math.sin(phi);
      const z = sphereRadius * Math.cos(theta);

      particles.push({
        x,
        y,
        z,
        ox: x,
        oy: y,
        oz: z,
        color: i % 2 === 0 ? "rgba(6, 182, 212, " : "rgba(168, 85, 247, ", // cyan or purple
        size: Math.random() * 2 + 1.5,
        vx: 0,
        vy: 0,
        vz: 0,
        type: "sphere"
      });
    }

    // Engineering helical paths (representing AI sequence structure)
    const helixCount = Math.floor(particleCount * 0.6);
    const helixLength = width < 768 ? 400 : 700;
    for (let i = 0; i < helixCount; i++) {
      const progress = (i / helixCount) - 0.5; // -0.5 to 0.5
      const angle = progress * Math.PI * 8; // spiral wraps
      const r = width < 768 ? 80 : 120; // helix radius

      // Helix Strand A
      const hxa = Math.cos(angle) * r;
      const hya = hxa * 0.2; // slight lean
      const hza = progress * helixLength;
      
      particles.push({
        x: hxa,
        y: progress * helixLength,
        z: Math.sin(angle) * r,
        ox: hxa,
        oy: progress * helixLength,
        oz: Math.sin(angle) * r,
        color: "rgba(6, 182, 212, ", // Cyan strand
        size: Math.random() * 1.5 + 1.2,
        vx: 0,
        vy: 0,
        vz: 0,
        type: "helix_a"
      });

      // Helix Strand B (180deg offset)
      const hxb = Math.cos(angle + Math.PI) * r;
      const hzb = Math.sin(angle + Math.PI) * r;
      particles.push({
        x: hxb,
        y: progress * helixLength,
        z: hzb,
        ox: hxb,
        oy: progress * helixLength,
        oz: hzb,
        color: "rgba(168, 85, 247, ", // Purple strand
        size: Math.random() * 1.5 + 1.2,
        vx: 0,
        vy: 0,
        vz: 0,
        type: "helix_b"
      });
    }

    // Mouse interactive handlers
    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current.x = e.clientX;
      mouseRef.current.y = e.clientY;
      mouseRef.current.rx = (e.clientX - width / 2) * 0.0004; // rotate scale based on cursor
      mouseRef.current.ry = (e.clientY - height / 2) * 0.0004;
      mouseRef.current.active = true;
    };

    const handleMouseLeave = () => {
      mouseRef.current.active = false;
    };

    window.addEventListener("mousemove", handleMouseMove);
    document.addEventListener("mouseleave", handleMouseLeave);

    const handleResize = () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener("resize", handleResize);

    // Dynamic rotation angles
    let curRotX = 0;
    let curRotY = 0;

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      const centerX = width / 2;
      const centerY = height / 2;

      // Slow drag rotation based on mouse orientation (+ auto rotation drift)
      const targetRotX = mouseRef.current.active ? mouseRef.current.rx : 0;
      const targetRotY = mouseRef.current.active ? mouseRef.current.ry : 0;

      // smooth interpolation of the angles
      curRotX += (targetRotX - curRotX) * 0.05;
      curRotY += (targetRotY - curRotY) * 0.05;

      const computedAngleX = angleX + curRotY * 0.6; // mouse Y controls X-axis rotation
      const computedAngleY = angleY + curRotX * 0.6; // mouse X controls Y-axis rotation

      const cosX = Math.cos(computedAngleX);
      const sinX = Math.sin(computedAngleX);
      const cosY = Math.cos(computedAngleY);
      const sinY = Math.sin(computedAngleY);

      // We sort particles by Z depth to render back-to-front (depth buffer/painters algorithm)
      const projected: {
        sx: number;
        sy: number;
        scale: number;
        p: Particle;
        depth: number;
      }[] = [];

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];

        // 1. Rotate around Y axis
        let x1 = p.x * cosY - p.z * sinY;
        let z1 = p.x * sinY + p.z * cosY;

        // 2. Rotate around X axis
        let y2 = p.y * cosX - z1 * sinX;
        let z2 = p.y * sinX + z1 * cosX;

        // 3. Constant incremental drift
        p.x = x1;
        p.y = y2;
        p.z = z2;

        // Interactive mouse force
        if (mouseRef.current.active) {
          // Re-project approximate 3D to 2D
          const screenScale = focalLength / (focalLength + z2 + 300);
          const px = centerX + x1 * screenScale;
          const py = centerY + y2 * screenScale;

          const dx = mouseRef.current.x - px;
          const dy = mouseRef.current.y - py;
          const dist = Math.sqrt(dx * dx + dy * dy);

          // If mouse is close, draw them slightly towards the mouse vector
          if (dist < 180) {
            const force = (180 - dist) * 0.0004;
            p.vx += dx * force;
            p.vy += dy * force;
          }
        }

        // Return forces / spring resistance back to native math grid shape
        p.vx += (p.ox - p.x) * 0.015;
        p.vy += (p.oy - p.y) * 0.015;
        p.vz += (p.oz - p.z) * 0.015;

        // Damping velocity
        p.vx *= 0.92;
        p.vy *= 0.92;
        p.vz *= 0.92;

        p.x += p.vx;
        p.y += p.vy;
        p.z += p.vz;

        // Project onto 2D viewport
        const distanceOffset = 450; // Distance of camera
        const depth = z2 + distanceOffset;

        if (depth > 50) {
          const scale = focalLength / depth;
          const sx = centerX + p.x * scale;
          const sy = centerY + p.y * scale;

          projected.push({ sx, sy, scale, p, depth });
        }
      }

      // Sort back-to-front
      projected.sort((a, b) => b.depth - a.depth);

      // Draw connection lines ("Neural Webs")
      const connectionLimit = width < 768 ? 40 : 55;
      for (let i = 0; i < projected.length; i++) {
        const p1 = projected[i];

        // Draw only if it's within suitable distance range
        let connections = 0;
        for (let j = i + 1; j < projected.length; j++) {
          if (connections > 2) break; // Limit lines per particle for rendering efficiency
          const p2 = projected[j];

          // Compute 2D screen distance as a fast estimation
          const dx = p1.sx - p2.sx;
          const dy = p1.sy - p2.sy;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < connectionLimit) {
            // Factor line opacity by the closeness AND depth
            const opacity = (1 - dist / connectionLimit) * 0.16 * p1.scale;
            ctx.beginPath();
            ctx.moveTo(p1.sx, p1.sy);
            ctx.lineTo(p2.sx, p2.sy);
            // Gray-translucent connections or mixed color
            ctx.strokeStyle = p1.p.type === "sphere" 
              ? `rgba(6, 182, 212, ${opacity})`
              : `rgba(168, 85, 247, ${opacity})`;
            ctx.lineWidth = 0.5 * p1.scale;
            ctx.stroke();
            connections++;
          }
        }
      }

      // Draw particles
      for (let i = 0; i < projected.length; i++) {
        const { sx, sy, scale, p } = projected[i];
        
        // Size scales according to virtual scale
        const sizeScaled = p.size * scale * 1.5;
        if (sizeScaled > 0.1) {
          // Glow effect on center points
          const depthAlpha = Math.min(Math.max((scale * 0.95), 0.05), 1);
          ctx.beginPath();
          ctx.arc(sx, sy, sizeScaled, 0, Math.PI * 2);
          ctx.fillStyle = `${p.color}${depthAlpha})`;
          ctx.fill();

          // If extremely close to viewer, draw an inner core glow
          if (scale > 1.25) {
            ctx.beginPath();
            ctx.arc(sx, sy, sizeScaled * 0.4, 0, Math.PI * 2);
            ctx.fillStyle = "#ffffff";
            ctx.fill();
          }
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseleave", handleMouseLeave);
      window.removeEventListener("resize", handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full pointer-events-none z-0"
      style={{ opacity: 0.72 }}
    />
  );
}
