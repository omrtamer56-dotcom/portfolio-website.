import React, { useState } from "react";
import { Project } from "../types";
import { motion, AnimatePresence } from "motion/react";
import { ArrowUpRight, CheckCircle2, Code, Layers, Activity } from "lucide-react";

interface ProjectCardProps {
  project: Project;
  key?: any;
}

export default function ProjectCard({ project }: ProjectCardProps) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <motion.div
      layout
      id={`project-card-${project.id}`}
      className="relative group bg-cyber-card/80 border border-gray-800 rounded-2xl overflow-hidden hover:border-cyber-accent/60 transition-all duration-500 backdrop-blur-md flex flex-col h-full"
      whileHover={{ y: -4 }}
    >
      {/* Decorative Gradient Background Aura */}
      <div className="absolute inset-0 bg-gradient-to-br from-cyber-accent/5 via-transparent to-cyber-secondary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-700" />

      {/* Visual Asset Section */}
      <div className="relative h-48 overflow-hidden bg-gray-900 border-b border-gray-800">
        <img
          src={project.image}
          alt={project.title}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover opacity-70 group-hover:scale-105 transition-transform duration-700 select-none"
        />
        <div className="absolute top-4 left-4 bg-cyber-dark/80 backdrop-blur-md border border-gray-700 rounded-lg px-3 py-1 flex items-center gap-1.5 shadow-lg">
          <Activity className="w-3.5 h-3.5 text-cyber-accent" />
          <span className="text-xs font-mono font-medium text-gray-200">
            {project.metric.label}: <strong className="text-cyber-accent">{project.metric.value}</strong>
          </span>
        </div>

        {/* Hover Action Indication */}
        <div className="absolute inset-0 bg-cyber-dark/40 backdrop-blur-sm opacity-0 group-hover:opacity-100 flex items-center justify-center transition-all duration-300">
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="bg-cyber-accent hover:bg-cyan-500 text-cyber-dark font-display font-semibold px-4 py-2 rounded-xl flex items-center gap-1.5 shadow-lg transform translate-y-2 group-hover:translate-y-0 transition-all duration-300 pointer-events-auto cursor-pointer"
          >
            <span>{isOpen ? "Close Blueprint" : "Inspect Blueprint"}</span>
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Basic Card Copy */}
      <div className="p-6 flex flex-col flex-grow relative z-10">
        <h3 className="font-display font-semibold text-lg text-white group-hover:text-cyber-accent transition-colors duration-300">
          {project.title}
        </h3>
        
        <p className="text-sm text-gray-400 mt-2.5 flex-grow font-sans leading-relaxed">
          {project.excerpt}
        </p>

        {/* Tech Badges */}
        <div className="flex flex-wrap gap-1.5 mt-5">
          {project.tags.map((tag) => (
            <span
              key={tag}
              className="text-[10px] font-mono bg-cyber-dark px-2.5 py-1 rounded-md border border-gray-800 text-gray-300"
            >
              {tag}
            </span>
          ))}
        </div>

        {/* Action triggers */}
        <div className="mt-6 pt-4 border-t border-gray-800/60 flex items-center justify-between">
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="text-xs font-mono font-semibold text-gray-400 hover:text-cyber-accent transition-colors flex items-center gap-1 cursor-pointer"
          >
            {isOpen ? "[Hide Case Study]" : "[Reveal Deep Case Study]"}
          </button>
          
          {project.liveUrl && (
            <a
              href={project.liveUrl}
              className="text-[10px] uppercase tracking-wider font-mono font-bold text-cyber-secondary hover:text-purple-400 flex items-center gap-0.5 transition-colors"
            >
              Live Demo <ArrowUpRight className="w-3 h-3" />
            </a>
          )}
        </div>
      </div>

      {/* Expanded Deep Blueprint Information */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.4, ease: "easeInOut" }}
            className="overflow-hidden border-t border-gray-800 bg-cyber-deep/90 relative z-20"
          >
            <div className="p-6 space-y-5 text-sm leading-relaxed border-b border-gray-800">
              <div className="space-y-2">
                <span className="text-[10px] font-mono text-cyber-accent font-bold uppercase tracking-widest block">
                  Executive Briefing
                </span>
                <p className="text-gray-300 text-xs">
                  {project.description}
                </p>
              </div>

              {/* Metric Breakdown */}
              <div className="p-3.5 rounded-xl bg-cyber-dark/40 border border-gray-800/80 space-y-1.5">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-cyber-accent animate-pulse" />
                  <span className="text-[10px] font-mono text-gray-400 uppercase tracking-widest">
                    Impact Metric Log
                  </span>
                </div>
                <p className="text-xs text-gray-300">
                  {project.metricsDetail}
                </p>
              </div>

              {/* Stack Architecture Highlights */}
              <div className="space-y-2.5">
                <span className="text-[10px] font-mono text-cyber-secondary font-bold uppercase tracking-widest block flex items-center gap-1">
                  <Layers className="w-3.5 h-3.5" /> High-End Architecture Specs
                </span>
                <ul className="space-y-1.5 text-xs text-gray-400">
                  {project.architectureBreakdown.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-cyber-accent shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Inline Code Highlight if provided */}
              {project.codeHighlightSnippet && (
                <div className="space-y-2">
                  <span className="text-[10px] font-mono text-gray-400 font-bold uppercase tracking-widest block flex items-center gap-1">
                    <Code className="w-3.5 h-3.5 text-cyber-emerald" /> Core Engine Highlights
                  </span>
                  <pre className="bg-cyber-dark border border-gray-800 rounded-lg p-3 overflow-x-auto text-[10px] text-gray-300 font-mono leading-relaxed">
                    <code>{project.codeHighlightSnippet}</code>
                  </pre>
                </div>
              )}

              {/* Form Close trigger */}
              <div className="pt-2 flex justify-end">
                <button
                  onClick={() => setIsOpen(false)}
                  className="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 text-[10px] font-mono text-white rounded-lg transition-colors cursor-pointer"
                >
                  Collapse Case Study
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
