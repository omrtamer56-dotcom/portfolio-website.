import { Project } from "./types";

export const PORTFOLIO_PROJECTS: Project[] = [
  {
    id: "aether-mesh",
    title: "AetherMesh — AI-Driven Autonomous Form & Layout Generator",
    excerpt: "A premium software interface that utilizes real-time generative streaming pipelines to live-render customized React Tailwind layouts.",
    description: "Built to demonstrate direct technical expertise using React hooks, server-sent streaming prompt flows, and optimized virtual layouts. Clients enter natural prompts to receive immediate tailored interactive layouts. Constructed securely with safe server endpoints, proving high-end product speed.",
    category: "ai_app",
    tags: ["React 19", "@google/genai", "TypeScript", "Tailwind CSS v4"],
    image: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80",
    metric: { value: "3.2s", label: "Render Velocity" },
    metricsDetail: "Instantly creates rich interactive mock components ready for copy-paste using the raw capabilities of current LLM prompt speeds.",
    architectureBreakdown: [
      "Secured system-level API access to hide access keys completely from client logs.",
      "Custom state streaming pipelines displaying instantaneous text progress.",
      "Optimized client iframe sandbox rendering that blocks script injection."
    ],
    codeHighlightSnippet: `// Server-Sent Prompt Pipeline Initializer
export async function streamAgentChain(prompt: string, res: Response) {
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  const responseStream = await ai.models.generateContentStream({
    model: "gemini-3.5-flash",
    contents: prompt
  });
  for await (const chunk of responseStream) {
    res.write(chunk.text);
  }
}`
  },
  {
    id: "quantum-ledger",
    title: "QuantumLedger — Extreme Density WebGL Financial Dashboard",
    excerpt: "A sub-millisecond, highly-optimized responsive corporate trading dashboard configured for multi-dimensional pipelines.",
    description: "An advanced technical showcase emphasizing extreme rendering performance. Renders dense finance trade pipelines using custom 2D canvas drawing buffers, bypassing standard rendering performance bottlenecks. Optimized to retain 60FPS fluid motion on mobile screens.",
    category: "fullstack",
    tags: ["WebGL", "TypeScript", "React Optimization", "Canvas Math"],
    image: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&w=800&q=80",
    metric: { value: "60 FPS", label: "Fluid Rendering Rate" },
    metricsDetail: "Implements strict frame virtualization & offscreen matrix math to compute coordinate grids safely on high-density displays.",
    architectureBreakdown: [
      "Off-screen layout buffering preventing micro-stutters during dynamic scrolling.",
      "Fully responsive column layout that snaps fluidly matching mobile aspect-ratios.",
      "Surgical component isolation preventing needless React standard re-renders."
    ],
    codeHighlightSnippet: `// Offscreen Double-Buffering Frame Scheduler
class FrameScheduler {
  private backCanvas = document.createElement("canvas");
  private activeRequest: number | null = null;

  public queueFrame(renderTask: (ctx: CanvasRenderingContext2D) => void) {
    if (this.activeRequest) cancelAnimationFrame(this.activeRequest);
    this.activeRequest = requestAnimationFrame(() => {
      renderTask(this.backCanvas.getContext("2d")!);
      this.flushToDisplay();
    });
  }
}`
  },
  {
    id: "omni-scribe",
    title: "OmniScribe — Automated Intelligent Client Briefing Portal",
    excerpt: "An interactive, natural conversation intake application converting client project ideas into formal technical requirements.",
    description: "A production-grade onboarding suite showcasing artificial intelligence system integration. Prospective clients hold fluid conversations with the system, and it generates beautiful markdown briefs, outline drafts, and accurate work scope models autonomously.",
    category: "interactive",
    tags: ["Gemini API", "Express.js Backend", "Node.js", "State Integration"],
    image: "https://images.unsplash.com/photo-1551434678-e076c223a692?auto=format&fit=crop&w=800&q=80",
    metric: { value: "+240%", label: "Visitor Conversion Uplift" },
    metricsDetail: "Increases prospective customer action rates by replacing boring static form submission buttons with engaging generative dialog streams.",
    architectureBreakdown: [
      "Dynamic input sanitation protecting databases from malicious prompt payloads.",
      "Bespoke theme injection updating color details on the client based on text analysis.",
      "Robust state persistence allowing users to resume chats continuously."
    ]
  }
];

export const CORE_TECH_STACKS = [
  { name: "Node.js & Express Full-Stack", level: 98, role: "High-performance server routers, API proxies, and token management routines." },
  { name: "React 19 & TypeScript", level: 95, role: "Robust state architecture, custom hooks, and strict compile-time type-safety guarantees." },
  { name: "Framer Motion Animations", level: 92, role: "Premium hardware-accelerated transitions, viewport scroll sensing, and structural page pacing." },
  { name: "Gemini AI Orchestration", level: 96, role: "Dynamic prompt engineering, response validation schemas, and real-time structured content." }
];

export const AGENCY_FEATURES = [
  {
    title: "I Sell Premium Websites",
    description: "I build bespoke internet identities designed to establish absolute authority and drive high client conversions. No generic templates, no cookie-cutter layouts. Every line of code is meticulously written to align with elite standards of performance, custom UI typography, and user engagement."
  },
  {
    title: "Created with the Help of AI",
    description: "This portfolio and my entire production workflow are engineered using the synergistic power of senior architectural software experience and cutting-edge generative AI. By integrating advanced artificial intelligence models directly into my coding pipelines, I achieve unprecedented development speeds, error-free deployments, and robust integrated smart components 5-10x faster than traditional agencies."
  },
  {
    title: "Premium AI-Powered Services",
    description: "I deliver end-to-end fullstack development services augmented with dynamic intelligence. These include automated onboarding portals, custom conversational layouts, responsive 3D WebGL backdrops, intelligent semantic search modules, and hyper-optimized mobile architectures."
  }
];
