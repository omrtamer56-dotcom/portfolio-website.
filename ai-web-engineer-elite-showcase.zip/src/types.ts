export interface Project {
  id: string;
  title: string;
  excerpt: string;
  description: string;
  category: "all" | "ai_app" | "fullstack" | "interactive";
  tags: string[];
  image: string;
  metric: { value: string; label: string };
  metricsDetail: string;
  architectureBreakdown: string[];
  codeHighlightSnippet?: string;
  liveUrl?: string;
}

export interface ProposalInput {
  businessName: string;
  businessType: string;
  aesthetic: string;
  features: string[];
}

export interface ColorPaletteItem {
  name: string;
  hex: string;
  rationale: string;
}

export interface SiteSectionItem {
  sectionName: string;
  purpose: string;
  microAnimation: string;
  aiFactor: string;
}

export interface AiIntegrationItem {
  title: string;
  concept: string;
  benefit: string;
}

export interface ProposalResult {
  tagline: string;
  colorPalette: ColorPaletteItem[];
  siteArchitecture: SiteSectionItem[];
  aiIntegrations: AiIntegrationItem[];
  timeline: string[];
  closingPitch: string;
}

export interface CalculatorState {
  complexity: "mvp" | "premium" | "enterprise";
  featuresSelected: string[];
  speed: "relaxed" | "standard" | "accelerated";
}
